﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
	public partial class Form1 : Form
	{
		const int BRACKET_WIDTH = 50;

		public Form1()
		{
			InitializeComponent();
		}

		private void name_box_Leave(object sender, EventArgs e)
		{
			if (((TextBox)sender).Text == "")
			{
				((TextBox)sender).Text = "Name...";
				((TextBox)sender).ForeColor = Color.Gray;
			}
		}

		private void only_numbers(object sender, KeyPressEventArgs e)
		{
			char character = e.KeyChar;
			if (!(character >= '0' && character <= '9' || character == Convert.ToChar(Keys.Back)))
			{
				e.Handled = true;
			}
		}

		private void age_box_Leave(object sender, EventArgs e)
		{
			if (((TextBox)sender).Text == "")
			{
				((TextBox)sender).Text = "Age...";
				((TextBox)sender).ForeColor = Color.Gray;
			}
		}

		private void division_box_Leave(object sender, EventArgs e)
		{
			if (((TextBox)sender).Text == "")
			{
				((TextBox)sender).Text = "Division...";
				((TextBox)sender).ForeColor = Color.Gray;
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Form bracket = new Form();
			Label baseLabel = new Label();
			baseLabel.Text = "_________";
			baseLabel.Width = BRACKET_WIDTH;
			baseLabel.Padding = Padding.Empty;
			int depth = (names_listbox.Rows.Count) / 2;
			double power = Math.Pow(2, depth-1);
			baseLabel.Location = new Point(5, (int)((power + names_listbox.Rows.Count) * baseLabel.Height));
			bracket.Controls.Add(baseLabel);
			bracket.Controls.AddRange(generateBracket(baseLabel, names_listbox.Rows.Count - 1).ToArray());
			bracket.Show();
		}

		
		private List<Label> generateBracket(Label baseLabel, int size)
		{
			List<Label> labels = new List<Label>();
			int depth = (size + 1) / 2;
			if (size > 1)
			{
				Label top = new Label();
				top.Text = "________";
				top.Width = BRACKET_WIDTH;
				top.Location = new Point(baseLabel.Right, baseLabel.Top -  depth * baseLabel.Height);
				top.Parent = baseLabel;
				top.Padding = Padding.Empty;
				labels.Add(top);
				labels.AddRange(generateBracket(top, (size + 1) / 2));


				Label bottom = new Label();
				bottom.Text = "________";
				bottom.Width = BRACKET_WIDTH;
				bottom.Top = baseLabel.Top + baseLabel.Height * depth;
				bottom.Left = baseLabel.Right;
				bottom.Parent = baseLabel;
				bottom.Padding = Padding.Empty;
				labels.Add(bottom);
				labels.AddRange(generateBracket(bottom, size / 2));
			}

			return labels;
		}
	}
}
